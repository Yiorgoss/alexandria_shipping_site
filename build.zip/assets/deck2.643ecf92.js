var e="/assets/deck2.137980bd.jpg";export{e as default};
