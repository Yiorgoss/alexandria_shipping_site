var a="/assets/anthea_1.529177e8.jpg";export{a as default};
