var a="/assets/aeolos_4.c8393522.jpg";export{a as default};
