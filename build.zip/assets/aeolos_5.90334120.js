var a="/assets/aeolos_5.d49f4a4d.jpg";export{a as default};
