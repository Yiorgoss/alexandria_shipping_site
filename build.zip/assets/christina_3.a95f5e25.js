var a="/assets/christina_3.ccf101f1.jpg";export{a as default};
