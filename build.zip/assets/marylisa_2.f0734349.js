var a="/assets/marylisa_2.7361abc4.jpg";export{a as default};
