var c="/assets/contact_us.d12ec6cc.jpg";export{c as default};
