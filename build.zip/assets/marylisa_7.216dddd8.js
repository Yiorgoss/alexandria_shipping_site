var a="/assets/marylisa_7.05386006.jpg";export{a as default};
