var a="/assets/marylisa_6.f2417b16.jpg";export{a as default};
