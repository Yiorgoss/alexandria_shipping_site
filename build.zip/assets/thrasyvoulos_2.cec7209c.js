var s="/assets/thrasyvoulos_2.006fbf2f.jpg";export{s as default};
