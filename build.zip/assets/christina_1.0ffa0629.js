var a="/assets/christina_1.77f02b3b.jpg";export{a as default};
