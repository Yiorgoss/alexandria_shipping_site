var a="/assets/anthea_5.bf795a15.jpg";export{a as default};
