var a="/assets/anthea_4.491b7ef5.jpg";export{a as default};
