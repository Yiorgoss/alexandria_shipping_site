var e="/assets/aeolos_1.e53cf86e.jpg";export{e as default};
