var a="/assets/aeolos_2.764cd769.jpg";export{a as default};
