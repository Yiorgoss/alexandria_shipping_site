var a="/assets/marylisa_1.05511c41.jpg";export{a as default};
