var a="/assets/anthea_3.206bf880.jpg";export{a as default};
