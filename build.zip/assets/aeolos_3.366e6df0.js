var a="/assets/aeolos_3.000146fa.jpg";export{a as default};
