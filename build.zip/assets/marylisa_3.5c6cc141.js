var a="/assets/marylisa_3.eaa4a744.jpg";export{a as default};
