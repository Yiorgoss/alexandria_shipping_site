var s="/assets/thrasyvoulos_1.10d65c28.jpg";export{s as default};
