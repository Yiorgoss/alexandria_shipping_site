var a="/assets/marylisa_4.5ed1435c.jpg";export{a as default};
