var a="/assets/anthea_2.4f7cd76a.jpg";export{a as default};
