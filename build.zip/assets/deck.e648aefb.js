var e="/assets/deck.60e86398.jpg";export{e as default};
