var a="/assets/carousel_main.730eaadd.jpg";export{a as default};
