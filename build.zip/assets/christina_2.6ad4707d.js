var a="/assets/christina_2.a22d44c2.jpg";export{a as default};
