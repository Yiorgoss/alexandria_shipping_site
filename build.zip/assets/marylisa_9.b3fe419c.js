var a="/assets/marylisa_9.69275af5.jpg";export{a as default};
