var a="/assets/marylisa_8.4d36de32.jpg";export{a as default};
