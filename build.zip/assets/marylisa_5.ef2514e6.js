var a="/assets/marylisa_5.b777ce5f.jpg";export{a as default};
